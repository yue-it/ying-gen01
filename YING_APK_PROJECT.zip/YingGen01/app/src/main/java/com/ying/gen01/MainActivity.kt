package com.ying.gen01

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var btnStart: Button
    private lateinit var btnMode: Button
    private lateinit var seekX: SeekBar
    private lateinit var seekY: SeekBar
    private var askedNotif = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("ying", MODE_PRIVATE)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        val title = TextView(this)
        title.text = "YING_GEN01"
        title.textSize = 22f
        root.addView(title)

        val info = TextView(this)
        info.text = "Avatar melayang di atas aplikasi lain. Geser avatar dengan jari untuk memindahkan."
        info.setPadding(0, pad / 2, 0, pad)
        root.addView(info)

        btnStart = Button(this)
        btnStart.setOnClickListener {
            if (OverlayService.running) {
                stopService(Intent(this, OverlayService::class.java))
                btnStart.text = "Mulai avatar"
            } else {
                startAvatar()
            }
        }
        root.addView(btnStart, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        btnMode = Button(this)
        btnMode.setOnClickListener {
            val now = prefs.getString("mode", "mic")
            prefs.edit().putString("mode", if (now == "mic") "tap" else "mic").apply()
            updateModeText()
        }
        root.addView(btnMode, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val modeInfo = TextView(this)
        modeInfo.text = "Mode Mic: mulut bergerak mengikuti suara. Mode Ketuk: mic dilepas untuk TikTok, tap avatar saat mulai/berhenti bicara."
        modeInfo.textSize = 12f
        modeInfo.setPadding(0, 0, 0, pad)
        root.addView(modeInfo)

        root.addView(label("Sensitivitas mic"))
        root.addView(seek("sens", 60))
        root.addView(label("Ukuran avatar"))
        root.addView(seek("size", 40))
        root.addView(label("Posisi kiri - kanan (horizontal)"))
        seekX = seek("px", 5)
        root.addView(seekX)
        root.addView(label("Posisi atas - bawah (vertical)"))
        seekY = seek("py", 30)
        root.addView(seekY)

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
        updateModeText()
    }

    private fun label(t: String): TextView {
        val v = TextView(this)
        v.text = t
        v.setPadding(0, 16, 0, 0)
        return v
    }

    private fun seek(key: String, def: Int): SeekBar {
        val s = SeekBar(this)
        s.max = 100
        s.progress = prefs.getInt(key, def)
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) prefs.edit().putInt(key, p).apply()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        return s
    }

    private fun updateModeText() {
        val m = prefs.getString("mode", "mic")
        btnMode.text = if (m == "mic") "Mode: Mic (tekan untuk ganti)" else "Mode: Ketuk tanpa mic (tekan untuk ganti)"
    }

    override fun onResume() {
        super.onResume()
        btnStart.text = if (OverlayService.running) "Hentikan avatar" else "Mulai avatar"
        seekX.progress = prefs.getInt("px", 5)
        seekY.progress = prefs.getInt("py", 30)
    }

    private fun startAvatar() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && !askedNotif &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotif = true
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Aktifkan 'Tampilkan di atas aplikasi lain', lalu kembali dan tekan Mulai lagi",
                Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        btnStart.text = "Hentikan avatar"
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && (grantResults.isEmpty() || grantResults[0] != PackageManager.PERMISSION_GRANTED)) {
            Toast.makeText(this, "Izin mikrofon dibutuhkan agar aplikasi bisa jalan", Toast.LENGTH_LONG).show()
            return
        }
        startAvatar()
    }
}
