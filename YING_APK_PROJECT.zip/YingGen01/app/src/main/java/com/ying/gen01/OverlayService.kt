package com.ying.gen01

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.util.DisplayMetrics
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.max
import kotlin.random.Random

class OverlayService : Service() {

    companion object {
        @Volatile
        var running = false
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private lateinit var img: ImageView
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var dClosed: Drawable
    private lateinit var dOpen: Drawable

    private val ui = Handler(Looper.getMainLooper())
    private var isOpen = false
    private var talking = false

    @Volatile
    private var recording = false
    private var thread: Thread? = null

    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var moved = false

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "size") applySize()
        if (key == "mode") applyMode()
        if (key == "px" || key == "py") applyPosition()
    }

    private val flapRunnable = object : Runnable {
        override fun run() {
            if (!talking) return
            setOpen(!isOpen)
            val d = if (isOpen) 80 + Random.nextInt(140) else 60 + Random.nextInt(120)
            ui.postDelayed(this, d.toLong())
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onCreate() {
        super.onCreate()
        running = true
        prefs = getSharedPreferences("ying", MODE_PRIVATE)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()

        dClosed = resources.getDrawable(R.drawable.mulut_tutup, theme)
        dOpen = resources.getDrawable(R.drawable.mulut_buka, theme)

        img = ImageView(this)
        img.setImageDrawable(dClosed)
        img.scaleType = ImageView.ScaleType.FIT_CENTER

        val size = sizePx()
        lp = WindowManager.LayoutParams(
            size,
            size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = 0

        img.setOnTouchListener(touch)
        wm.addView(img, lp)
        applyPosition()

        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        applyMode()
    }

    private val touch = View.OnTouchListener { _, e ->
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                startX = lp.x
                startY = lp.y
                moved = false
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (e.rawX - downX).toInt()
                val dy = (e.rawY - downY).toInt()
                if (abs(dx) > 12 || abs(dy) > 12) moved = true
                if (moved) {
                    val sz = screenSize()
                    lp.x = (startX + dx).coerceIn(0, max(0, sz.first - lp.width))
                    lp.y = (startY + dy).coerceIn(0, max(0, sz.second - lp.height))
                    wm.updateViewLayout(img, lp)
                }
            }
            MotionEvent.ACTION_UP -> {
                if (moved) {
                    val sz = screenSize()
                    val rx = max(1, sz.first - lp.width)
                    val ry = max(1, sz.second - lp.height)
                    val npx = (lp.x * 100f / rx).toInt().coerceIn(0, 100)
                    val npy = (lp.y * 100f / ry).toInt().coerceIn(0, 100)
                    prefs.edit().putInt("px", npx).putInt("py", npy).apply()
                } else if (prefs.getString("mode", "mic") == "tap") {
                    toggleTalking()
                }
            }
        }
        true
    }

    private fun sizePx(): Int {
        val dp = 60 + prefs.getInt("size", 40) * 3
        return (dp * resources.displayMetrics.density).toInt()
    }

    private fun applySize() {
        val s = sizePx()
        lp.width = s
        lp.height = s
        applyPosition()
    }

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        return Pair(dm.widthPixels, dm.heightPixels)
    }

    private fun applyPosition() {
        val sz = screenSize()
        val px = prefs.getInt("px", 5)
        val py = prefs.getInt("py", 30)
        lp.x = (px / 100f * max(0, sz.first - lp.width)).toInt()
        lp.y = (py / 100f * max(0, sz.second - lp.height)).toInt()
        try {
            wm.updateViewLayout(img, lp)
        } catch (e: Exception) {
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        ui.postDelayed({ applyPosition() }, 300)
    }

    private fun setOpen(o: Boolean) {
        if (o == isOpen) return
        isOpen = o
        img.setImageDrawable(if (o) dOpen else dClosed)
    }

    private fun toggleTalking() {
        talking = !talking
        if (talking) {
            ui.post(flapRunnable)
        } else {
            ui.removeCallbacks(flapRunnable)
            setOpen(false)
        }
    }

    private fun applyMode() {
        val m = prefs.getString("mode", "mic")
        if (m == "mic") {
            talking = false
            ui.removeCallbacks(flapRunnable)
            startRecording()
        } else {
            stopRecording()
            setOpen(false)
        }
    }

    private fun toast(msg: String) {
        ui.post { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
    }

    private fun startRecording() {
        if (recording) return
        val rate = 16000
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) {
            toast("Mic tidak tersedia di HP ini")
            return
        }
        val rec: AudioRecord? = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC,
                rate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                minBuf * 2
            )
        } catch (e: Exception) {
            null
        }
        if (rec == null || rec.state != AudioRecord.STATE_INITIALIZED) {
            rec?.release()
            toast("Mic gagal dibuka (mungkin dipakai aplikasi lain). Coba Mode Ketuk.")
            return
        }
        recording = true
        thread = Thread {
            val buf = ShortArray(1024)
            var lastLoud = 0L
            try {
                rec.startRecording()
                while (recording) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n <= 0) {
                        Thread.sleep(20)
                        continue
                    }
                    var sum = 0.0
                    for (i in 0 until n) {
                        val v = buf[i] / 32768.0
                        sum += v * v
                    }
                    val rms = Math.sqrt(sum / n)
                    val sens = prefs.getInt("sens", 60)
                    val thr = 0.004 + (100 - sens) / 100.0 * 0.08
                    val now = SystemClock.uptimeMillis()
                    if (rms > thr) lastLoud = now
                    val open = now - lastLoud < 150
                    ui.post { if (recording) setOpen(open) }
                }
            } catch (e: Exception) {
                // berhenti diam-diam
            } finally {
                try { rec.stop() } catch (e: Exception) { }
                rec.release()
            }
        }
        thread?.start()
    }

    private fun stopRecording() {
        recording = false
        thread = null
    }

    private fun startAsForeground() {
        val chId = "ying_overlay"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(chId, "YING_GEN01", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, chId)
            .setContentTitle("YING_GEN01 aktif")
            .setContentText("Avatar melayang. Ketuk untuk membuka pengaturan.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    override fun onDestroy() {
        running = false
        recording = false
        ui.removeCallbacksAndMessages(null)
        try { prefs.unregisterOnSharedPreferenceChangeListener(prefListener) } catch (e: Exception) { }
        try { wm.removeView(img) } catch (e: Exception) { }
        super.onDestroy()
    }
}
